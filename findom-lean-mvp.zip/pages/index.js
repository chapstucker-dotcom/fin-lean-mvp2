export default function Home() {
  return (
    <div style={{fontFamily: 'sans-serif', textAlign: 'center', marginTop: '40px'}}>
      <h1>Findom Lean MVP</h1>
      <p>Welcome to your AI Financial Dominatrix test platform.</p>
    </div>
  );
}